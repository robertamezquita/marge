library(testthat)
library(marge)

test_check("marge")
