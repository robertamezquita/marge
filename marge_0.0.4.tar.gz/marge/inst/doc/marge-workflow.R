## ------------------------------------------------------------------------
salutation <- c('hello world')
salutation # view output

## ---- eval=FALSE---------------------------------------------------------
#  ## In a terminal/command-line
#  perl /path-to-homer/configureHomer.pl -install hg38 # human sequence data
#  perl /path-to-homer/configureHomer.pl -install mm10 # mouse sequence data

## ------------------------------------------------------------------------
## Install `marge`:
## devtools::install_github('robertamezquita/marge', ref = 'master')
library(marge)

check_homer()
list_homer_packages()

## ---- message=FALSE------------------------------------------------------
## Use included test regions from `marge` package
test_file <- system.file('extdata/test_regions.bed', package = 'marge')
dat <- readr::read_tsv(test_file)

dat

## ------------------------------------------------------------------------
## Create a temporary directory to write results
## This directory is erased once R session is closed
results_dir <- tempfile(pattern = 'test-dir_')

## ---- eval=FALSE---------------------------------------------------------
#  ## Run a motif enrichment analysis
#  find_motifs_genome(
#      dat,
#      path = results_dir,
#      genome = 'mm10',
#      motif_length = 8,
#      scan_size = 50,
#      optimize_count = 2,
#      background = 'automatic',
#      local_background = FALSE,
#      only_known = FALSE, only_denovo = FALSE,
#      fdr_num = 5,
#      cores = 1, cache = 100,
#      overwrite = TRUE, keep_minimal = FALSE
#  )

## ---- eval=FALSE---------------------------------------------------------
#  known  <- read_known_results(path = results_dir, homer_dir = TRUE)
#  denovo <- read_denovo_results(path = results_dir, homer_dir = TRUE)
#  
#  known
#  denovo

## ---- echo=FALSE---------------------------------------------------------
known  <- read_known_results(path = system.file('extdata', package = 'marge'))
denovo <- read_denovo_results(path = system.file('extdata', package = 'marge'))

known
denovo

## ---- eval=FALSE---------------------------------------------------------
#  ## Known Motifs
#  known$motif_pwm[1]             # positional access
#  known$motif_pwm['OCT:OCT']     # named access
#  
#  ## Denovo Motifs
#  denovo$motif_pwm[1]            # positional access

## ------------------------------------------------------------------------
denovo$motif_pwm['1-TCGCATTG'] # named access (denovo)

## ---- eval=FALSE---------------------------------------------------------
#  ## Note double bracket to access list value;
#  ## single bracket produces error
#  write_homer_motif(
#      motif_pwm = denovo$motif_pwm[['1-TCGCATTG']],
#      motif_name = 'my_first_motif',
#      log_odds_detection = 4.35,
#      consensus = 'CACATCCT',
#      file = paste0(results_dir, '/my_first_motif.motif')
#  )

## ---- eval=FALSE---------------------------------------------------------
#  ## Write to multiple files - vary the `file` argument
#  library(purrr)
#  pwalk(
#      .l = list(
#          motif_pwm  = denovo$motif_pwm,
#          motif_name = denovo$motif_name,
#          log_odds_detection = denovo$log_odds_detection,
#          consensus = denovo$consensus,
#          file = paste0(results_dir, '/', denovo$motif_name, '.motif')
#      ),
#      .f = write_homer_motif
#  )
#  
#  ## Write to a single file with all motifs
#  ## Keep the `file` argument constant
#  my_motifs_file <- paste0(results_dir, '/my-motifs.motif')
#  
#  ## Append by default is TRUE, e.g. can write more than one
#  ## motif at once, but this means don't run this code more
#  ## than once!
#  pwalk(
#      .l = list(
#          motif_pwm  = denovo$motif_pwm,
#          motif_name = denovo$motif_name,
#          log_odds_detection = denovo$log_odds_detection,
#          consensus = denovo$consensus
#       ),
#      .f = write_homer_motif,
#      file = my_motifs_file,
#      append = TRUE
#  )

## ---- eval=FALSE---------------------------------------------------------
#  motif_instances_file <- paste0(results_dir, '/motif-instances.txt')
#  
#  find_motifs_instances(
#      dat,
#      path = motif_instances_file,
#      genome = 'mm10',
#      motif_file = my_motifs_file,
#      scan_size = 50,
#      cores = 1, cache = 100
#  )

## ---- eval=FALSE---------------------------------------------------------
#  motif_instances <- read_motifs_instances(motif_instances_file)
#  
#  motif_instances

## ---- echo=FALSE---------------------------------------------------------
motif_instances <- read_motifs_instances(
    system.file('extdata/motif-instances.txt', package = 'marge')
)

motif_instances

## ---- message=FALSE, warning=FALSE---------------------------------------
## Required libraries for advanced usage tutorial
library(valr)
library(dplyr)
library(tidyr)
library(purrr)
library(ggplot2)

## ------------------------------------------------------------------------
## 1. Construct multiple region samples -------------------------------------
## Create genome from first two chromosomes of mouse
genome <- data.frame(chrom = c('chr1', 'chr2'),
                     size = c(195471971, 182113224))

## Set seeds and ids for the simulated sets of regions
seed <- 1:5
id <- letters[1:5]

## Simulate different sets of regions (each with unique seeds) and munge
## into the tibble format, keeping the regions as a list-column
sim <- map(seed, ~ valr::bed_random(genome, length = 50, n = 50, seed = .x))
tbl_regions <- tibble(id = id, regions = sim)

## Inspect overall tibble organization
tbl_regions

## View regions sample
tbl_regions$regions[[1]] %>% print(n = 5)

## ------------------------------------------------------------------------
## 2. Find Motifs in Genome -------------------------------------------------

## Create new (temp) results directory
results_dir <- tempfile(pattern = 'ht-dir_')

## Append results path to tibble of regions
tbl_regions <- tbl_regions %>%
    mutate(path = paste0(results_dir, '/homer_', id))

tbl_regions[1, ] # inspect resulting first row

## ---- eval=FALSE---------------------------------------------------------
#  ## Iterate over all regions to perform motif finding
#  ## Writing each set of regions results to different directory
#  ## Only perform known motif results enrichments
#  pwalk(
#      ## Varying parameters (regions, output directory)
#      .l = list(x = tbl_regions$regions, path = tbl_regions$path),
#      ## Function to find motifs across genome
#      .f = find_motifs_genome,
#      ## Constant parameters (motif search settings)
#      genome = 'mm10',
#      scan_size = 50,
#      optimize_count = 2,
#      only_known = TRUE,
#      cores = 2, cache = 100,
#      keep_minimal = TRUE, overwrite = TRUE
#  )

## ---- eval=FALSE---------------------------------------------------------
#  ## 3. Read in All Results ----------------------------------------------------
#  
#  ## Read known motif enrichment results into a new list-column
#  ## Remove the path and regions columns for cleanliness
#  ## Unnest results to expand into plotting friendly format
#  tbl_results <- tbl_regions %>%
#      mutate(known_results = map(path, read_known_results)) %>%
#      select(-path, -regions) %>%
#      unnest()

## ---- echo=FALSE---------------------------------------------------------
## Hidden chunk to load `tbl_results` from package
load(system.file('extdata/tbl_results.rda', package = 'marge'))

## ------------------------------------------------------------------------
## View sampling of results
tbl_results %>% sample_n(size = 5)

## ------------------------------------------------------------------------
## Summarise number of 
tbl_summary <- tbl_results %>%
    group_by(id, motif_family) %>%
    summarise(top_log_p_value = max(log_p_value)) %>%
    ungroup()

## Print example results
tbl_summary %>% sample_n(5)

## ------------------------------------------------------------------------
families <- c('AP2', 'bHLH', 'bZIP', 'CCAAT', 'CP2')

tbl_summary %>%
    filter(motif_family %in% families) %>%
    ggplot(aes(x = motif_family, y = id, fill = top_log_p_value)) +
    geom_tile()

